package ee;

public class ItemDarkSword extends ItemRedSword {
	public ItemDarkSword(int v) {
		super(v);
	}
}
