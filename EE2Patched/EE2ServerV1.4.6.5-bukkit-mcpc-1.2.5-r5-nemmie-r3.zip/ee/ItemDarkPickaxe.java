package ee;

public class ItemDarkPickaxe extends ItemRedPickaxe {
	public ItemDarkPickaxe(int v) {
		super(v);
		emcEatFactor = .7;
	}
}
