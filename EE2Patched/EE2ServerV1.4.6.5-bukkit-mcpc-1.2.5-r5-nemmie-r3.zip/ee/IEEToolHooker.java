package ee;

public interface IEEToolHooker {
	public void addEEToolBlockBreakCatchItemId(int id);
}
