package ee;

public class ItemDarkAxe extends ItemRedAxe {
	public ItemDarkAxe(int v) {
		super(v);
		emcEatFactor = .7;
	}
}
