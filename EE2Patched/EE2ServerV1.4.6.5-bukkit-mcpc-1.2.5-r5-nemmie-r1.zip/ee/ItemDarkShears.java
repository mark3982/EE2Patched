package ee;

public class ItemDarkShears extends ItemRedShears {
	public ItemDarkShears(int v) {
		super(v);
	}
}
