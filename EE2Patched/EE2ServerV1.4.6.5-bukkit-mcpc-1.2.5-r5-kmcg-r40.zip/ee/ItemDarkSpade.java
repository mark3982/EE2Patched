package ee;

public class ItemDarkSpade extends ItemRedSpade {
	public ItemDarkSpade(int v) {
		super(v);
	}
}
