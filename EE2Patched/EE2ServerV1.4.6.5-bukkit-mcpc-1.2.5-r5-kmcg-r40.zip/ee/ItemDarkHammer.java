package ee;

public class ItemDarkHammer extends ItemRedHammer {
	public ItemDarkHammer(int v) {
		super(v);
	}
}
