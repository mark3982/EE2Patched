package ee;

import ee.core.GuiIds;
import net.minecraft.server.mod_EE;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.ItemStack;

public class TileRelay3 extends TileRelayBase {
  public TileRelay3() {
	  items = new ItemStack[22];
	  this.klein = (this.items.length - 1);
  }
	
  public boolean onBlockActivated(EntityHuman var1)
  {
    if (!this.world.isStatic)
    {
      var1.openGui(mod_EE.getInstance(), GuiIds.RELAY_3, this.world, this.x, this.y, this.z);
    }

    return true;
  }
}
