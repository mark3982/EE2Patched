package ee;

public class ItemDarkHoe extends ItemRedHoe {
	public ItemDarkHoe(int v) {
		super(v);
		emcEatFactor = .7;
	}
}
